document.addEventListener("DOMContentLoaded", function() {
    fetch('/playbooks')
        .then(response => response.json())
        .then(data => {
            const tableBody = document.getElementById('playbooksTable').getElementsByTagName('tbody')[0];
            data.playbooks.forEach(playbook => {
                const row = tableBody.insertRow();
                const cellName = row.insertCell(0);
                const cellAction = row.insertCell(1);

                cellName.textContent = playbook;
                const deployButton = document.createElement('button');
                deployButton.textContent = 'Deploy';
                deployButton.onclick = function() {
                    fetch('/deploy', { 
                        method: 'POST', 
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ playbook: playbook }) 
                    });
                };

                cellAction.appendChild(deployButton);
            });
        });
});
