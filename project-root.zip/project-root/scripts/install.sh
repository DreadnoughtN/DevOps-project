#!/bin/bash


sudo apt-get update
sudo apt-get install ansible -y

 cd ansible-project

cat << EOF > inventory.ini
[local]
localhost ansible_user=ubuntu ansible_connection=ssh
EOF

cat << EOF > ansible.cfg
[defaults]
inventory = inventory.ini
host_key_checking = false
EOF

ssh-keygen -t rsa -f ~/.ssh/id_rsa -q -P ""

cat ~/.ssh/id_rsa.pub >> ~/.ssh/authorized_keys

ansible-playbook playbook.yml
