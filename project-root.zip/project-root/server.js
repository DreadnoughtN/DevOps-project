const express = require('express');
const bodyParser = require('body-parser');
const { exec } = require('child_process');
const path = require('path');

const app = express();
const PORT = 80;
const ANSIBLE_DIRECTORY = path.join(__dirname, 'ansible');

app.use(express.static(path.join(__dirname, 'frontend')));

app.use(bodyParser.json());

app.get('/', (req, res) => { res.sendFile(path.join(__dirname, 'frontend', 'index.html')); });

app.get('/playbooks', (req, res) => {
    const fs = require('fs');
    fs.readdir(ANSIBLE_DIRECTORY, (err, files) => {
        if (err) {
            return res.status(500).json({ error: 'Could not retrieve playbooks' });
        }
        const playbooks = files.filter(file => file.endsWith('.yml'));
        res.json({ playbooks });
    });
});

app.post('/deploy', (req, res) => {
    const playbook = req.body.playbook;
    console.log(`Received request to deploy playbook: ${playbook}`);
    if (!playbook) {
        console.error('No playbook provided');
        return res.status(400).json({ error: 'Playbook is required' });
    }



    const terraformApply = `cd terraform && sudo -u ubuntu terraform apply -var="playbook_name=${playbook}" -auto-approve -lock=false`;
    console.log(`Executing command: ${terraformApply}`);

    exec(terraformApply, (error, stdout, stderr) => {
        if (error) {
            console.error(`Error deploying: ${stderr}`);
            return res.status(500).json({ error: 'Deployment failed' });
        }
        console.log(`Successfully deployed: ${stdout}`);
        res.json({ message: 'Deployment started' });

        setTimeout(() => {
            const terraformDestroy = 'cd terraform && terraform destroy -var="playbook_name=${playbook}" -auto-approve';
            console.log(`Executing destroy command: ${terraformDestroy}`);

            exec(terraformDestroy, (destroyError, destroyStdout, destroyStderr) => {
                if (destroyError) {
                    console.error(`Error destroying: ${destroyStderr}`);
                } else {
                    console.log(`Successfully destroyed: ${destroyStdout}`);
                }
            });
        }, 15 * 60 * 1000);
    });
});


app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
